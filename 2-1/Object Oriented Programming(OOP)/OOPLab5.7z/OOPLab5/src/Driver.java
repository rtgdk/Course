
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e = new Employee("John Doe", 10000);
		Employee m = new Manager("Jolly Doe", 100000, "Justice");
		System.out.println(e);
		System.out.println(m);
	}

}
