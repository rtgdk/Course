
public class TestWorker {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Worker ftw = new FulltimeWorker("John Doe", 100.0, 140);
		Worker hw = new HourlyWorker("Jolly Doe", 50.00, 50);

//		Error because Worker class does not have a computePay method
      	System.out.println(hw.computePay());
		
//		Prints "Class Full Time Worker" because ftw is a FulltimeWorker
//		object and it overrides the show method from worker class.
		ftw.show();
		
//		Print "Class Worker" because hw is a HourlyWorker object but
//		it does not have show() method overridden so it uses show() method
//		from Worker class
		hw.show();
	}

}
