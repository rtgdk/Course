
abstract class Worker {
	private String name;
	private double salary_rate;
	abstract double computePay();
	public Worker(String name, double salary_rate) {
		this.name = name;
		this.salary_rate = salary_rate;
	}
	
	public String getName() {
		return name;
	}

	public double getSalary_rate() {
		return salary_rate;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setSalary_rate(double salary_rate) {
		this.salary_rate = salary_rate;
	}

	public void show() {
		System.out.println("Class Worker");
	}
	
}

class FulltimeWorker extends Worker {
	
	private int hours_worked;
	
	public FulltimeWorker(String name, double salary_rate, int hours) {
		super(name, salary_rate);
		this.hours_worked = hours;
	}
	
	public double computePay() {
		return super.getSalary_rate()*hours_worked;
	}
	
	public void show() {
		System.out.println("Class Full Time Worker");
	}
}

class HourlyWorker extends Worker {
	
	private int hours_worked;
	
	public HourlyWorker(String name, double salary_rate, int hours) {
		super(name, salary_rate);
		this.hours_worked = hours;
	}
	
	public double computePay() {
		return super.getSalary_rate()*hours_worked;
	}
	public void show() {
		System.out.println("hour Full Time Worker");
	}
}