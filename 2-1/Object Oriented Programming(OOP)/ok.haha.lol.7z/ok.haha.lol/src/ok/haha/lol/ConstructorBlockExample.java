package ok.haha.lol;

public class ConstructorBlockExample {
	{
		System.out.println("This is first constructor block");
	}
	
	public ConstructorBlockExample() {
		System.out.println("This is no parameter constructor");
	}
	
	public ConstructorBlockExample(String param1) {
		System.out.println("This is Single Parameter Constructor");
	}
	
	{
		System.out.println("This is a second constructor block");
	}
	
	public static void main (String[] args) {
		ConstructorBlockExample constrBlockEx = new ConstructorBlockExample();
		ConstructorBlockExample constrBlockEx1 = new ConstructorBlockExample("param 1");
	}
}
