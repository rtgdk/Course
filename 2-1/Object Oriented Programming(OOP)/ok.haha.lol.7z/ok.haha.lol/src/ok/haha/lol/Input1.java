package ok.haha.lol;

import java.io.*;

public class Input1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter your name - ");
		String name = in.readLine();
		System.out.print(name);

	}

}
