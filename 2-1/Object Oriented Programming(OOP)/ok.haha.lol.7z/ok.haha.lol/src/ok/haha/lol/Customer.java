package ok.haha.lol;

public class Customer {

	private String name;
	private String idNo;
	private double balance;
	private Item item;
	
	//Constructors Begin
	
	public Customer(String name, String idNo, double balance) {
		this.name = name;
		this.idNo = idNo;
		this.balance = balance;
	}
	
	public Customer(String name,  String idno) {
		this.name = name;
		this.idNo = idNo;
		this.balance = 5000;
	}
	
	//Accessors Begin
	
	public String getName() {
		return this.name;
	}
	
	public String getIdNo() {
		return this.idNo;
	}
	
	public double getBalance() {
		return this.balance;
	}
	
	public Item getItem() {
		return this.item;
	}
	
	//Mutators Begin
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}
	
	//Other Methods Begin
	
	public void print() {
		System.out.println(item.getItemName());
		System.out.println(item.getItemidNo());
		System.out.println(item.getItemQuantity());
		System.out.println(item.getItemPrice());
		System.out.println(this.balance);
	}
	
	public void buyItem(Item item) {
		if(balance<=item.getItemPrice()) {
			System.out.println("Insufficient Balance");
		} else if (item.getItemQuantity()<=0) {
			System.out.println("Invalid Order");
		} else {
			this.item = item;
			balance-=(item.getItemPrice()*item.getItemQuantity());
			print();
		}
	}
}
