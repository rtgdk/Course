package ok.haha.lol;

import java.io.*;

public class Ex1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		int k=0;
		for(int i=0;i<10;i++) {
			k+=Integer.parseInt(in.readLine());
		}
		System.out.print(k);
	}

}
