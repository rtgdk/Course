package ok.haha.lol;

import java.util.Scanner;

public class Input2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1;
		double double1;
		String numStr1, numStr2;
		
		Scanner in = new Scanner(System.in);
		System.out.println("Enter an Integer: ");
		num1=in.nextInt();
		System.out.println("You entered: " + num1);
		
		System.out.println("Enter a double: ");
		double1=in.nextDouble();
		System.out.println("You Entered: " + double1);
		
		System.out.println("Enter your First Name: ");
		numStr1=in.next();
		System.out.println("You Entered: " + numStr1);
		
		System.out.println("Enter your Last Name: ");
		numStr2=in.next();
		System.out.println("You Entered: " + numStr2);
		in.close();
	}

}
