package ok.haha.lol;

public class BOX {
	private double length, width, height;

	public BOX(double length, double width, double height) {
		this.length = length;
		this.width = width;
		this.height = height;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public String toString() {
		return "length=" + length + ", width=" + width + ", height="
				+ height;
	}
	
	public double area() {
		return 2*(length*width + width*height + height*length);
	}
	
	public double volume() {
		return length*width*height;
	}
	
	public static void swapBoxes(BOX b1, BOX b2) {
		BOX temp = b1; b1=b2; b2 = temp;
	}
	
	
}

class BOXtest1 {
	public static void main(String[] args) {
		BOX b1 = new BOX(10,40,60);
		BOX b2 = new BOX(20,30,80);
		System.out.println(b1);
		System.out.println(b2);
		BOX.swapBoxes(b1, b2);
		System.out.println(b1);
		System.out.println(b2);
	}
}

class BOXTest2 {
	public static void main(String[] args) {
		BOX b1 = new BOX(10,40,60);
		BOX b2 = new BOX(20,30,80);
		System.out.println(b1);
		System.out.println(b2);
		BOX temp =b1;
		b1=b2; b2=temp;
		System.out.println(b1);
		System.out.println(b2);
	}
}
