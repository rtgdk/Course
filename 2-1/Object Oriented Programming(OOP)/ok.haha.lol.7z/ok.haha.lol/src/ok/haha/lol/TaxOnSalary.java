package ok.haha.lol;

import java.util.Scanner;

public class TaxOnSalary {
	private double salary;
	private boolean isPanSubmitted;
	
	public TaxOnSalary(boolean isPanSubmitted) {
		this.isPanSubmitted = isPanSubmitted;
		this.salary = 1000.00;
	}
	
	public TaxOnSalary() {
	}

	public double getSalary() {
		return salary;
	}

	public boolean getIsPanSubmitted() {
		return isPanSubmitted;
	}
	
	public double calculateTax() {
		double tax = 0.0;
		if(this.salary<180000) {
			if(this.isPanSubmitted!=true) {
				tax = this.salary*.05;
			}
		} else if(this.salary<500000) {
			tax = this.salary*.1;
		} else if(this.salary<1000000) {
			tax = this.salary*.2;
		} else {
			tax = this.salary*.3;
		}
		return tax;
	}

	public void inputSalary() {
		Scanner in = new Scanner(System.in);
		salary = in.nextDouble();
	}
	
	
}
