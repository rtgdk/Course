package ok.haha.lol;

import java.util.Scanner;

public class Ex2 {
	public static void main(String[] args){
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in); 
		int k=0;
		for(int i=0;i<10;i++) {
			k+=in.nextInt();
		}
		System.out.print(k);
	}
}
