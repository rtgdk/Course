package ok.haha.lol;

public class Static1 {
	int a;
	static int b;
	Static1() {
		b++;
	}
	
	public void showData() {
		System.out.println("a = "+ a);
		System.out.println("b= "+ b);
	}
	
	public static void increment() {
		//a++;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Static1 s1 = new Static1();
		s1.showData();
		Static1 s2 = new Static1();
		s2.showData();
		Static1.b++;
		s1.showData();
	}

}
