package ok.haha.lol;

public class RaceTrack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car car = new Car(2010, "Great", 30);
		System.out.println(car.getYear());
		System.out.println(car.getMake());
		System.out.println(car.getSpeed());
		car.accelerate();
		System.out.println(car.getSpeed());
		car.accelerate(10);
		System.out.println(car.getSpeed());
		car.Break(4);
		System.out.println(car.getSpeed());
		car = new Car();
		System.out.println(car.getYear());
		System.out.println(car.getMake());
		System.out.println(car.getSpeed());
		car.accelerate();
		System.out.println(car.getSpeed());
		car.accelerate(10);
		System.out.println(car.getSpeed());
		car.Break(4);
		System.out.println(car.getSpeed());
	}

}
