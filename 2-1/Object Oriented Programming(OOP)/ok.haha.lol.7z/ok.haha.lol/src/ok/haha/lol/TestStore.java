package ok.haha.lol;

import java.util.Scanner;

public class TestStore {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Enter your name - ");
		String name = in.next();
		System.out.println("Enter your ID - ");
		String idNo = in.next();
		System.out.println("Enter the current balance - ");
		double balance = in.nextDouble();
		
		Customer customer = new Customer(name, idNo, balance);
		
		System.out.println("Enter details for Item - 1");
		System.out.println("Enter item name - ");
		String itemName = in.next();
		System.out.println("Enter Item id - ");
		String itemidNo = in.next();
		System.out.println("Enter itemQuantity");
		int itemQuantity = in.nextInt();
		System.out.println("Enter itemPrice");
		double itemPrice = in.nextDouble();
		
		Item item1 = new Item(itemName, itemidNo, itemQuantity, itemPrice);
		
		System.out.println("Enter details for Item - 2");
		System.out.println("Enter item name - ");
		itemName = in.next();
		System.out.println("Enter Item id - ");
		itemidNo = in.next();
		System.out.println("Enter itemQuantity");
		itemQuantity = in.nextInt();
		System.out.println("Enter itemPrice");
		itemPrice = in.nextDouble();
		
		Item item2 = new Item(itemName, itemidNo, itemQuantity, itemPrice);
		
		customer.buyItem(item1);
		customer.buyItem(item2);
	}

}
