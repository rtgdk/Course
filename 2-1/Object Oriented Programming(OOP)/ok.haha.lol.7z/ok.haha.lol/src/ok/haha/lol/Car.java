package ok.haha.lol;

public class Car {
	private int year;
	private String make;
	private double speed;
	
	public Car(int year, String make, double speed) {
		this.year = year;
		this.make = make;
		this.speed = speed;
	}
	
	public Car() {
	
	}

	public int getYear() {
		return year;
	}

	public String getMake() {
		return make;
	}

	public double getSpeed() {
		return speed;
	}
	
	public void accelerate() {
		speed+=1;
	}
	
	public void accelerate(int increment) {
		speed+=increment;
	}
	
	public void Break(int b){
		speed -= Math.sqrt(b);
	}
	
}
