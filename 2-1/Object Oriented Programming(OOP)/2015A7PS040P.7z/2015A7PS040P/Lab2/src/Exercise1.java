import java.io.*; // java.io package is imported
// for using BufferedReader class
class Exercise1{
	public static void main(String args[]) throws IOException{

 		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr) ;
		int i=0;
		int sum=0;
		for(i=0;i<10;i++){
 			System.out.println("Enter "+(i+1) +"No:" );

			String no = br.readLine();
			sum+=Integer.parseInt(no) ;
		}
		System.out.println("Sum is: " + sum);
	} 
}