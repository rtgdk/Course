
public class Consumer {
	private String name ;
	private String idNo ;
	private double balance;
	private Item item ;
	public Consumer(String a,String b,double c){
		this.name=a;
		this.idNo=b;
		this.balance=c;
	}
	public Consumer(String a,String b){
		this.name=a;
		this.idNo=b;
		this.balance=5000.0;
	}
	public String getname()   {
		return name;   
	}
	public String getidNo()   {
		return idNo;   
	}
	public double getbalance()   {
		return balance;   
	}
	public Item getitem()   {
		return item;   
	}
	public void setname(String a){
		this.name = a;   
	}
	public void setidnNo(String a){
		this.idNo = a;   
	}

	
	public void print(){
		System.out.println("Item Name:"+this.item.getitemName());
		System.out.println("Item Id:"+this.item.getitemidNo());
		System.out.println("Item qunatity:"+this.item.getitemQuantity());
		System.out.println("Item price:"+this.item.getitemPrice());
		System.out.println("balance:"+this.getbalance());
	}
	
	public void buyItem(Item item){
		if ((item.getitemQuantity()> 1) && (item.getitemPrice()<this.getbalance())) {
			System.out.println("Item Name:"+item.getitemName());
			System.out.println("Item Id:"+item.getitemidNo());
			System.out.println("Item qunatity:"+item.getitemQuantity());
			System.out.println("Item price:"+item.getitemPrice());
			System.out.println("balance:"+this.getbalance());
		}
		else if (item.getitemQuantity()< 1){
			System.out.println("Order is invalid");
		}
		else {
			System.out.println("Insufficient balance");
		}
	}
}
