import java.util.Scanner; 
public class TestStore {
	public static void main(String args[]){
		 double double1;
		 String numStr1, numStr2;
		 Scanner in = new Scanner(System.in);
		 System.out.println("Enter balance: ");
		 double1=in.nextDouble();//reads an int from keyboard
		 System.out.println("Enter Name ");
		 numStr1 = in.next();
		 in.nextLine(); //to consume enter
		 System.out.println("Enter id No.");
		 numStr2 = in.nextLine();
		 in.close();
		 Consumer a= new Consumer(numStr1,numStr2,double1);
		 Item b= new Item("rohit","r",23,34.5);
		 Item c= new Item("mohit","m",243,344.5);
		 a.buyItem(b);
	}
	

}
