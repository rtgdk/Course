import java.util.Scanner; 
public class Example1b {

	public static void main(String[] args) {
		int num1=0,sum=0,i=0;
		Scanner in = new Scanner(System.in);
		for(i=0;i<10;i++){
			System.out.println("Enter an integer: "+(i+1));
			num1 = in.nextInt(); 
			sum+=num1;
		}
		 System.out.println("Sum:"+sum);
		 in.close();
	}

}
