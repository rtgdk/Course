
public class Item {

		private String itemName ;
		private String itemidNo ;
		private int itemQuantity ;
		private double itemPrice;
		public Item(String a,String b,int c, double d){
			this.itemName=a;
			this.itemidNo=b;
			this.itemQuantity=c;
			this.itemPrice=d;
		}
		public Item(String a,String b,int c){
			this.itemName=a;
			this.itemidNo=b;
			this.itemQuantity=c;
			this.itemPrice=500.0;
		}
		public Item(String a,String b){
			this.itemName=a;
			this.itemidNo=b;
			this.itemQuantity=1;
			this.itemPrice=500.0;
		}
		public String getitemName()   {
			return itemName;   
		}
		public String getitemidNo()   {
			return itemidNo;   
		}
		public int getitemQuantity()   {
			return itemQuantity;   
		}
		public double getitemPrice()   {
			return itemPrice;   
		}
		public void setitemName(String a){
			this.itemName = a;   
		}
		public void setitemidNo(String a){
			this.itemidNo = a;   
		}
		public void setitemQuantity(int a){
			this.itemQuantity = a;   
		}
		public void setitemPrice(double a){
			this.itemPrice = a;   
		}


}
