import java.util.Scanner;


public class Test2 {
	public  static Address readAddress() {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter 3 Lines:-");
		String line1 = in.nextLine();
		String line2 = in.nextLine();
		String line3 = in.nextLine();
		System.out.println("Enter City:-");
		String city = in.nextLine();
		System.out.println("Enter State:-");
		String state = in.nextLine();
		System.out.println("Enter Pin:-");
		String pin = in.nextLine();
		return new Address(line1+"$"+line2+"$"+line3+"$"+city+"$"+state+"$"+pin);
	}
	
	public static void main(String[] args) {
		Address[] x = new Address[5];
		for(int i = 0; i < 5; i++)
			x[i] = readAddress();
		
		Address a[] =  AddressList.getAddressWithCity(x, "BKN");
		Address b[] =  AddressList.getAddressWithPin(x, "334003");
		System.out.println("BKN:--");
		for(int i = 0; i <a.length; i++)
			System.out.println(a[i]);
		System.out.println("334003:--");
		for(int j = 0; j < b.length; j++)
			System.out.println(b[j]);
	}
}
