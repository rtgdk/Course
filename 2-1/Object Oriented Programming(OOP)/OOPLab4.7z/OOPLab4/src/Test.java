import java.io.IOException;
import java.util.Scanner;


public class Test {
	public static Student readStudent() throws IOException {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter First Name:-");
		String fname = in.nextLine();
		System.out.println("Enter Middle Name:-");
		String mname = in.nextLine();
		System.out.println("Enter Last Name:-");
		String lname = in.nextLine();
		System.out.println("Enter Format Name(1 for comma ans 2 for semicolon):-");
		int form = in.nextInt();
		System.out.println("Enter Age:-");
		int age = in.nextInt();
		Name name;
		if(form == 1)
			name = new Name(fname+","+mname+","+lname);
		else
			name = new Name(lname+";"+mname+";"+fname);
		Student std = new Student(name, age);
		return std;
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		for(int i = 0; i < 1; i++)
			StudentList.addStudent(readStudent());
		Student[] stds = StudentList.getStudentsWithAge(20);
		for(int i = 0; i < stds.length; i++)
			System.out.println(stds[i].toString());
		stds = StudentList.getStudentsWithLastName("Sharma");
		for(int i = 0; i < stds.length; i++)
			System.out.println(stds[i].toString());
		stds = StudentList.getStudentsInRange(16, 20);
		for(int i = 0; i < stds.length; i++)
			System.out.println(stds[i].toString());
	}

}
