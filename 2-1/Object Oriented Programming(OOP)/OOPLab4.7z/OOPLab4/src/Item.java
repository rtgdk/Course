
public class Item {
	private int itemId;
	private double price;
	
	public Item(int itemId, double price) {
		this.itemId = itemId;
		this.price = price;
	}
	public int getId() { return itemId; }
	public double getPrice() { return price; }
}
