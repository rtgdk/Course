import java.util.StringTokenizer;


public class Name {
	private String fname;
	private String mname;
	private String lname;
	
	public String getFname() {
		return fname;
	}
	public String getMname() {
		return mname;
	}
	public String getLname() {
		return lname;
	}
	public String getName() {
		return fname+" "+mname+" "+lname;
	}
	
	public Name(String name) {
		if(name.contains(";")) {
			String[] st = name.split(";");
			lname = st[0];
			mname = st[1];
			fname = st[2];
		}
		else if(name.contains(",")) {
			StringTokenizer st = new StringTokenizer(name, ",");
			fname = st.nextToken();
			mname = st.nextToken();
			lname = st.nextToken();
		}
	}
}
