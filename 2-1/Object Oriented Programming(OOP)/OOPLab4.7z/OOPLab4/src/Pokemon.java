
public class Pokemon {
	String name;
	int id;
	String type;
	
	public Pokemon(Strin s) {
		// TODO Auto-generated constructor stub
		String[] x = s.split('|');
	}
}
