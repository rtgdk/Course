
public class StudentList {
	public static Student[] list = new Student[10];
	public static int count  = 0;
	
	public static void addStudent(Student std) {
		if(count >= 10) return;
		list[count] = std;
		count++;
	}
	
	public static Student[] getStudentsWithAge(int age) {
		int x = 0;
		for(int i = 0; i < count; i++) {
			if(list[i].getAge() == age) {
				x++;
			}
		}
		Student[] stds = new Student[x];
		x = 0;
		for(int i = 0; i < count; i++) {
			if(list[i].getAge() == age) {
				stds[x] = list[i];
				x++;
			}
		}
		return stds;
	}
	
	public static Student[] getStudentsWithLastName(String lastname) {
		int x = 0;
		for(int i = 0; i < count; i++) {
			if(list[i].toString().split(" ")[2].compareTo(lastname) == 0) {
				x++;
			}
		}
		Student[] stds = new Student[x];
		x = 0;
		for(int i = 0; i < count; i++) {
			if(list[i].toString().split(" ")[2].compareTo(lastname) == 0) {
				stds[x] = list[i];
				x++;
			}
		}
		return stds;
	}
	
	public static Student[] getStudentsInRange(int minAge, int maxAge) {
		int x = 0;
		for(int i = 0; i < count; i++) {
			if(minAge <= list[i].getAge() && list[i].getAge() <= maxAge) {
				x++;
			}
		}		
		Student[] stds = new Student[x];
		x = 0;
		for(int i = 0; i < count; i++) {
			if(minAge <= list[i].getAge() && list[i].getAge() <= maxAge) {
				stds[x] = list[i];
				x++;
			}
		}
		return stds;
	}
}
