
public class AddressList {
	public static int countAddressWithCity(Address[] addressList, String city) {
		int count = 0;
		for(int i = 0; i <  addressList.length; i++) {
			if(addressList[i].getCity().compareTo(city) == 0)
				count++;
		}
		return count;
	}
	public static int countAddressWithPin(Address[] addressList, String strP) {
		int count = 0;
		for(int i = 0; i <  addressList.length; i++) {
			if(addressList[i].getPin().compareTo(strP) == 0)
				count++;
		}
		return count;
	}
	public static Address[] getAddressWithCity(Address[] addressList, String city) {
		int count = AddressList.countAddressWithCity(addressList, city);
		int x = 0;
		Address[] addrs = new Address[count];
		for(int i = 0; i <  addressList.length; i++) {
			if(addressList[i].getCity().compareTo(city) == 0) {
				addrs[x] = addressList[i];
				x++;
			}
		}
		return addrs;
	}
	public static Address[] getAddressWithPin(Address[] addressList, String strP) {
		int count = AddressList.countAddressWithPin(addressList, strP);
		int x = 0;
		Address[] addrs = new Address[count];
		for(int i = 0; i <  addressList.length; i++) {
			if(addressList[i].getPin().compareTo(strP) == 0) {
				addrs[x] = addressList[i];
				x++;
			}
		}
		return addrs;
	}
}
