import java.util.Vector;


public class NewRetailStore {
	private Vector<Item> items = new Vector<>();
	
	public void addItem(Item item) {
		items.add(item);
	}
	private double computePrice(int value) {
		for(Item item: items) {
			if(item.getId() == value)
				return item.getPrice();
		}
		return -1.0;
	}
	
	public static void main(String[] args) {
		NewRetailStore retailone = new NewRetailStore();
		retailone.addItem(new Item(1001, 13.50));
		retailone.addItem(new Item(1002, 18.00));
		retailone.addItem(new Item(1003, 19.50));
		retailone.addItem(new Item(1004, 25.50));
		
		System.out.println("price of item id 1002 is "+retailone.computePrice(1002));
		System.out.println("price of item id 1004 is "+retailone.computePrice(1004));
	}
}
