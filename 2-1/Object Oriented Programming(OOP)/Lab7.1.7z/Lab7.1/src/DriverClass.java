
public class DriverClass {
	public static void main(String args[]) {   
		Account a= new Account(12,23.2,"m1");
		Bank b = new Bank();
		b.addAccount(a);
		a= new Account(16,24,"m2");
		b.addAccount(a);
		b.deposit(16,44);
		System.out.println(b.toString());
		b.removeAccount(16);
		System.out.println(b.toString());
		
	}
}
