import java.util.Iterator; 
import java.util.ListIterator;  
public class MyLinkedList {     
	private Node head; //denotes the head of the linked list     
	private int size; //denotes the size of the linked list         
	
	// Constructors for Node Class      
	public class Node{      
		
	Object data; //Data to be held by the node, could be integer or string 
	Node next;  //Address of the next node in the linked list     
	
	public  Node(Object data) {
	this.data = data;  
	this.next=null;    
	}  
     public  Node(Object data, Node next) { 
    	 this.data = data;
    	 this.next = next; }     
     public String toString() { 
    	 String stringView = ""; 
     stringView += '[';
     stringView += data.toString(); 
     stringView += ']';  
           if (next != null) {                 
        	   stringView += '-';            
        	   }           
           return stringView;       
        	   }    
     }  
    // Constructors for MyLinkedList Class     
	public MyLinkedList() {       
	size = 0;    
	}     
	public MyLinkedList(Node head) {         
	this.head = head;         
	size = 1;     }   
	public MyLinkedList(Object headData) {        
		head = new Node(headData);         
		size = 1;    
}  
	
	
	
public Node reverse(){
	Node current=head, prev=null, nex=head ;
	while(current!=null){
		nex=current.next;
		current.next=prev;
		prev=current;
		current=nex;
	}
	head=prev;
	return head;
    }
	
	
	
   // Methods  
   //Getter and Setter methods for Head node       
public Node getHead() {  
return head;    }    

public void setHead(Node head) {  
	this.head = head; 
}    public int getSize() {   
	return size;   
}  
//Adding new Node at the beginning of the list 
public void add(Object data) {        
	Node e = new Node(data);        
	e.next = head;    
	head = e;        
size++;     } 
//Adding new Node at the end of the list    
public void addLast(Object data) {        
	if (head == null)            
		add(data);
        else {             
        	Node x = head;       
        while (x.next != null)               
        	x = x.next;     
        x.next = new Node(data);            
        size++;      
        }     }    
//Adding new Node at a particular index (Overloaded method)    
public void add(int index, Object data) {       
	if(checkElementIndex(index)==-1)
		return;  
        if (index == 0)             
        	add(data);       
        else {        
        		Node x = head;           
        		for (int i = 0; i < index - 1; i++) 
                x = x.next;            
        x.next = new Node(data, x.next);            
        size++;         }     }      
//Fetching a Node of a particular index       
public Object getElement(int index) {         
	if( checkElementIndex(index)==-1)
		return null;   
	Node x = head;         
	for (int i = 0; i < index; i++)         
		x = x.next;        
	return x.data;     
	}     //Removing the head Node of Linked List    
public Object removeFirst() {       
	if (size == 0)            
		return null;         
	else {            
		Object temp = head.data;    
	head = head.next;           
	size--;         
	return temp;         }     }  
//Removing the last Node of Linked List  
public Object removeLast() {       
	if (size <= 1)             
		return removeFirst();      
	else {             
		Node x = head;       
		while (x.next.next != null)    
			x = x.next;             
		Object temp = x.next.data;     
		x.next = null;       
		size--;  
		return temp;         }     }  
   //Removing the a particular Node of LinkedList   
public void remove(int index) {     
	if(checkElementIndex(index)==-1)return;    
	if (index == 0)             removeFirst();   
	else {             Node x = head;           
	for (int i = 0; i < index - 1; i++)             
		x = x.next;          
	x.next = x.next.next; 
		size--;         }    
	}    //Changing data value of a particular Node  
public Object setElement(int index, Object newData) 
{ 
        if(checkElementIndex(index)==-1)
        	return null;     
Node x = head;      
for (int i = 0; i < index; i++)         
	x = x.next;         
Object temp = x.data;       
x.data = newData;         
return temp;     } 
//Returns the index of the first occurrence of the data  
public int indexOf(Object data) {     
	Node x = head;         
	for (int i = 0; i < size; i++, x = x.next)   
		if (x.data.equals(data)) {             
			return i;             }       
	return -1;     } 
//Returns the index of the last occurrence of the data
public int lastIndexOf(Object data) {        
	int lastOccurrence = -1;         
	Node x = head;        
	for (int i = 0; i < size; i++, x = x.next)      
		if (x.data.equals(data))                
			lastOccurrence = i;        
	return lastOccurrence;     }  
//Helper Methods    
        //Checks whether a particular object is there in the list  
public boolean contains(Object o) {        
	for (Node x = head; x != null; x = x.next) {  
		if (x.data.equals(o)) {                
			return true;             }      
		}         return false;     }  
//Checks whether a particular index is feasible or not 
private int checkElementIndex(int index) {        
	if (index < 0 || size <= index)         
		return -1;       
	return 1;     }  
//Checks whether list is empty or not  
public boolean isEmpty() {   return head == null;    
}    // Returns the size of list 
         
public String toString() {        
	if (head == null) {           
		return "null"; 
		

        } else {             
        	StringBuilder stringView = new StringBuilder();   
        	// using StringBuilder inside loops is very efficient      
        	for (Node x = head; x != null; x = x.next)                
        		stringView.append(x.toString());             
        	return stringView.toString();         }     }  
    public String debugString() {         
    	return toString() + " (size: " + size + ")";    
    	} 
    public static void main(String args[]){
    	MyLinkedList m = new MyLinkedList(10);
    	m.add(15);
    	m.add(16);
    	m.add(17);
    	System.out.println(m.toString());
    	m.reverse();
    	System.out.println("after reversal "+m.toString());
    }
    } 