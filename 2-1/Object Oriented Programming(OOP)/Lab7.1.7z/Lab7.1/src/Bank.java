import java.util.ArrayList;
import java.util.ListIterator;

import javax.swing.text.html.HTMLDocument.Iterator;


public class Bank {
	private ArrayList<Account> accts = new ArrayList<Account>();
	int maxActive;  
	  public boolean addAccount (Account newone) 
	  { /* Write the code for adding new account,
	   return false if account can�t be created */ 
		  if(maxActive==30)
			  return false;
		  else {
			  accts.add(newone);
			  maxActive++;
			  return true;
		  }
		  
		  }   
	  public boolean removeAccount (long acctnum) 
	  {  /* Write the code for removing the account, 
	  return false if account does not exist */   
		  ListIterator<Account> li = accts.listIterator();
		  while(li.hasNext()){
			  Account acc = (Account)li.next();
			  if(acc.getAcctNumber()==acctnum){
				  accts.remove(acc);
				  return true;
			  }
		  }
		  return false;
		  
		  }
	  public double deposit(long acctnum, double amount) 
		  {    /* Write the code for depositing specified amount to 
		  the account,     return -1 if account does not exist */ 
		  ListIterator<Account> li = accts.listIterator();
		  while(li.hasNext()){
			  Account acc = (Account) li.next();
			  if(acc.getAcctNumber()==acctnum){
				  acc.setBalance(acc.getBalance()+amount);
				  return acc.getBalance();
			  }
		  }
		  return -1;
		  }   
		  public double withdraw(long acctnum, double amount) 
		  {    /* Write the code for withdrawing specified amount 
		  from the account,     return -1 if insufficient balance 
		  or account does not exist */   
			  ListIterator<Account> li = accts.listIterator();
			  while(li.hasNext()){
				  Account acc = (Account)li.next();
				  if(acc.getAcctNumber()==acctnum){
					  if(acc.getBalance()<amount)
						  return -1;
					  acc.setBalance(acc.getBalance()-amount);
					  return acc.getBalance();
				  }
			  }
			  return -1;
			  }
		  public String toString(){
			  java.util.Iterator<Account> itr =  accts.iterator();
			  String ans="";
			while(itr.hasNext()) {  
			      Object element = itr.next();       
			      ans+=(element.toString() + "\n");  
			  }
			return ans;
			}
		  //override toString() method to display details of all the accounts in bank  }
}
