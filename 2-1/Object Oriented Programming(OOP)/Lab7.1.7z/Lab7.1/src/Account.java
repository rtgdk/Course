
public class Account {
	  private long acctNumber;   
	  private double balance;   
	  private String name; 
	  public Account(long acctNumber,double balance,String name)
		{  this.name=name;  
		this.acctNumber=acctNumber;  
		this.balance=balance;  } 
	  
		public String getName(){   
			return name;  }  
		
		public double getBalance(){   
			return balance;  }  
		public void setBalance(double balance){   
			this.balance=balance;  
			} 
		
		public long getAcctNumber(){   
			return acctNumber;  }  
		public void setAcctNumber(long acctNumber){   
			this.acctNumber=acctNumber;  
			} 
		
		public void setName(String name){   
			this.name=name;  }  
		
		public String toString()
		{   return name+"   Account Number	"+acctNumber+" balance	"+balance;  }
}
