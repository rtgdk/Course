/* NULL_Pointer_Sample.c */

#include <stdio.h>

int main () {

int *ptr = NULL;

printf("The value of ptr is : %x\n", &ptr );

return 0;

}
