# include <stdio.h>
# include <stdlib.h>

# include "Stack.h"


// Global Variables
int curHeapSize;
int maxHeapSize;



// Wrapper Functions
void *myMalloc(unsigned int size);
void myFree(void *ptr);


int main(int argc, char *argv[]) {
	int *temp = (int *)myMalloc(sizeof(int));
	printf("Size to be Removed: %d\n", (int)sizeof(*temp));	
	myFree(temp);
	printf("Current Heap Size %d \nMaximum Heap Size %d\n", curHeapSize, maxHeapSize);	
	char *temp2 = (char *)myMalloc(sizeof(char));
	printf("Current Heap Size %d \nMaximum Heap Size %d\n", curHeapSize, maxHeapSize);
	
	printf("Size of temp is %d\n", (int)sizeof(*temp));
	void * temp3 = (void *)temp;
	printf("Size of temp is %d\n", (int)sizeof(*temp));

	return 0;
}


void *myMalloc(unsigned int size) {
	curHeapSize += size;
	if(curHeapSize > maxHeapSize)	maxHeapSize = curHeapSize;
	void *temp = (void *)malloc(size);
	return temp;
}

void myFree(void *ptr) {
	int size = (int)sizeof(*ptr);
	printf("Size to be Removed: %d\n", size);
	curHeapSize -= size;
	printf("\n\n %d \n", free(ptr));
}
