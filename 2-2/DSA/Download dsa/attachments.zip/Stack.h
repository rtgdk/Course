struct Node {
	int data;
	struct Node *next;
};

struct Stack {
	struct Node *head;
};

void print_stack(struct Stack *stack);
void push(struct Stack *stack, int data);
int pop(struct Stack *stack);


