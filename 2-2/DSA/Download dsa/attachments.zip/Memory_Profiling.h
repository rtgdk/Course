// Global Variables
int curHeapSize;
int maxHeapSize;

int ptr_size;

// Wrapper Functions
void *myMalloc(unsigned int size);
void myFree(void *ptr);
