# include <stdbool.h>

struct Node {
    int data;
    struct Node *next;
};

struct Queue {
    struct Node *head;
    struct Node *tail;
    int count;
};


struct Queue *create();
void print_queue(struct Queue *queue);

void add(struct Queue *queue, int data);
/* Adds at the end of the list. */

int delete(struct Queue *queue);
/* Deletes from the front of the list.
   Returns the data of the current head node, if it exists
   Otherwise returns -1. */

bool isEmpty(struct Queue *queue);
/* Returns true if queue is empty. Otherwise returns false. */

void traverse(struct Queue *queue);
