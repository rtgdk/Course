# include "Queue.h"
# include "Memory_Profiling.h"

# include <stdio.h>

struct Queue *mergeFIFO(struct Queue *q1, struct Queue *q2);
struct Queue *mergeLIST(struct Queue *q1, struct Queue *q2);

int main(int argc, char *argv[]) {
	//printf("Works");
	struct Queue *q1 = create();
	struct Queue *q2 = create();
	//printf("Works");
	for(int i=1; i<4; i+=2) {
		add(q1, i);
	}
	//printf("Works");
	/*for(int i=2; i<8; i+=2) {
		add(q2, i);
	}*/
	//printf("Works");
	struct Queue *q3 = mergeLIST(q1, q2);
	//printf("Works");	
	traverse(q3);
	return 0;
}

struct Queue *mergeFIFO(struct Queue *q1, struct Queue *q2) {
	struct Queue *q3 = create();	
	while(!isEmpty(q1) || !isEmpty(q2)) {
		if(isEmpty(q1)) {
			while(!isEmpty(q2)) {
				add(q3, delete(q2));
			}
		}
		else if(isEmpty(q2)) {
			while(!isEmpty(q1)) {
				add(q3, delete(q1));
			}
		}
		else {
			int elem1 = q1->head->data;
			int elem2 = q2->head->data;
			if(elem1 < elem2)	add(q3, delete(q1));
			else 	add(q3, delete(q2));
		}
	}
	return q3;
}

struct Queue *mergeLIST(struct Queue *q1, struct Queue *q2) {
	struct Queue *q3 = create();
	struct Node *iterator1 = q1->head;
	struct Node *iterator2 = q2->head;
	struct Node *iterator3 = NULL;

	while((iterator1 != NULL) || (iterator2 != NULL)) {
		if(iterator1 == NULL) {
			while(iterator2 != NULL) {
				if(iterator3){
					iterator3->next = iterator2;
					iterator3 = iterator3->next;
				}
				else {
					q3->head = iterator2;
					iterator3 = q3->head;				
				}
				iterator2 = iterator2->next;								
			}
		}
		else if(iterator2 == NULL) {
			while(iterator1 != NULL) {
				if(iterator3){
					iterator3->next = iterator1;
					iterator3 = iterator3->next; 
				}
				else{
					q3->head = iterator1;
					iterator3 = q3->head;
				}
				iterator1 = iterator1->next;								
			}
		}
		else {
			if(iterator1->data < iterator2->data) {
				if(iterator3){
					iterator3->next = iterator1;
					iterator3 = iterator3->next;
				}
				else{
					q3->head = iterator1;
					iterator3 = q3->head;
				}
				iterator1 = iterator1->next;
			}
			else {
				if(iterator3){
					iterator3->next = iterator2;
					iterator3 = iterator3->next;
				}
				else{
					q3->head = iterator2;
					iterator3 = q3->head;
				}
				iterator2 = iterator2->next;
			}
		}
		q3->count++;
	}
	return q3;
}
