# include "Memory_Profiling.h"

# include <stdio.h>
# include <stdlib.h>


void *myMalloc(unsigned int size) {
	curHeapSize += size;
	if(curHeapSize > maxHeapSize)	maxHeapSize = curHeapSize;
	void *temp = (void *)malloc(size);
	return temp;
}

void myFree(void *ptr) {
	int size = (int)sizeof(*ptr);
	//printf("Size to be Removed: %d\n", size);
	curHeapSize -= ptr_size;
	free(ptr);
}
