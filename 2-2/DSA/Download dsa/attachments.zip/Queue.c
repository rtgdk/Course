# include "Queue.h"
# include "Memory_Profiling.h"

# include <stdio.h>
# include <stdlib.h>
# include <stdbool.h>

struct Queue *create() {
    struct Queue *queue = (struct Queue *)myMalloc(sizeof(struct Queue));
    queue->head = NULL;
    queue->tail = NULL;
    queue->count = 0;
	return queue;    
}

void print_queue(struct Queue *queue) {
    struct Node *iterator = queue->head;
    while(iterator != NULL) {
		printf(" %d ", iterator->data);
		iterator = iterator->next;
	}
	printf("\n");
}

void add(struct Queue *queue, int data) {
	struct Node *new_node = (struct Node *)myMalloc(sizeof(struct Node));
	new_node->data = data;	
	new_node->next = NULL;
	if(queue->count == 0) {
		queue->tail = new_node;
		queue->head = new_node;
		queue->count++;
		return;
	}
	else {
		queue->tail->next = new_node;
		queue->tail = new_node;
		queue->count++;
	}
}

int delete(struct Queue *queue) {
	if(isEmpty(queue))	return -1;
	else {
		struct Node *temp = queue->head;
		queue->head = queue->head->next;
		int temp_data = temp->data;
		ptr_size = sizeof(*temp);
		myFree(temp);
		queue->count--;
		return temp_data;
	}
}

bool isEmpty(struct Queue *queue) {
	return (queue->count == 0);
}

void traverse(struct Queue *queue) {
	if(isEmpty(queue)) {
		printf("-1\n");
		return;
	}
	else {
		struct Node *iterator = queue->head;
    	while(iterator != NULL) {
			printf("%d\t", iterator->data);
			iterator = iterator->next;
		}
		printf("\n");
	}
}
