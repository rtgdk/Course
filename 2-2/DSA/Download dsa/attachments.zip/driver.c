#include "Queue.h"
#include "Memory_Profiling.h"

# include <stdio.h>
# include <stdbool.h>

struct Queue *mergeFIFO(struct Queue *q1, struct Queue *q2);
struct Queue *mergeLIST(struct Queue *q1, struct Queue *q2);



int main(int argc, char *argv[]) {
	int command;
	scanf("%d", &command);
	
	struct Queue *queue1 = NULL;
	struct Queue *queue2 = NULL;	
	while(true) {
		int i;
		if(command == 0) {
			if(queue1 == NULL) {
				queue1 = create();		
				int N;
				scanf("%d", &N);
				int data;
				for(i=0; i<N; i++) {
					scanf("%d", &data);
					add(queue1, data);
				}
				traverse(queue1);
			}
			else {
				queue2 = create();		
				int N;
				scanf("%d", &N);
				int data;
				for(i=0; i<N; i++) {
					scanf("%d", &data);
					add(queue2, data);
				}
				traverse(queue2);
			}
		}/*
		else if(command == 1) {
			int data;
			scanf("%d", &data);
			while(data != -1) {
				add(queue, data);
				scanf("%d", &data);
			}
			traverse(queue);
		}
		else if(command == 2) {
			int N;
			scanf("%d", &N);
			for(i=0; i<N; i++) {
				delete(queue);
			}
			traverse(queue);
		}
		else if(command == 3) {
			if(isEmpty(queue))	printf("1\n");
			else	printf("0\n");
		}
		else if(command == 4) {
			traverse(queue);
		}
		*/
		else if(command == 5) {
			struct Queue *queue3 = mergeFIFO(queue1, queue2);	
		}
		else if(command == 6) {
			struct Queue *queue3 = mergeLIST(queue1, queue2);	
		}
		else if(command == 7) {
			printf("%d\t%d\n", curHeapSize, maxHeapSize);
		}
		else if(command == -1) {
			break;
		}
		scanf("%d", &command);
	}
	return 0;
}


struct Queue *mergeFIFO(struct Queue *q1, struct Queue *q2) {
	struct Queue *q3 = create();	
	while(!isEmpty(q1) || !isEmpty(q2)) {
		if(isEmpty(q1)) {
			while(!isEmpty(q2)) {
				add(q3, delete(q2));
			}
		}
		else if(isEmpty(q2)) {
			while(!isEmpty(q1)) {
				add(q3, delete(q1));
			}
		}
		else {
			int elem1 = q1->head->data;
			int elem2 = q2->head->data;
			if(elem1 < elem2)	add(q3, delete(q1));
			else 	add(q3, delete(q2));
		}
	}
	traverse(q3);
	return q3;
}

struct Queue *mergeLIST(struct Queue *q1, struct Queue *q2) {
	struct Queue *q3 = create();
	struct Node *iterator1 = q1->head;
	struct Node *iterator2 = q2->head;
	struct Node *iterator3 = NULL;

	while((iterator1 != NULL) || (iterator2 != NULL)) {
		if(iterator1 == NULL) {
			while(iterator2 != NULL) {
				if(iterator3){
					iterator3->next = iterator2;
					iterator3 = iterator3->next;
				}
				else {
					q3->head = iterator2;
					iterator3 = q3->head;				
				}
				iterator2 = iterator2->next;								
			}
		}
		else if(iterator2 == NULL) {
			while(iterator1 != NULL) {
				if(iterator3){
					iterator3->next = iterator1;
					iterator3 = iterator3->next; 
				}
				else{
					q3->head = iterator1;
					iterator3 = q3->head;
				}
				iterator1 = iterator1->next;								
			}
		}
		else {
			if(iterator1->data < iterator2->data) {
				if(iterator3){
					iterator3->next = iterator1;
					iterator3 = iterator3->next;
				}
				else{
					q3->head = iterator1;
					iterator3 = q3->head;
				}
				iterator1 = iterator1->next;
			}
			else {
				if(iterator3){
					iterator3->next = iterator2;
					iterator3 = iterator3->next;
				}
				else{
					q3->head = iterator2;
					iterator3 = q3->head;
				}
				iterator2 = iterator2->next;
			}
		}
		q3->count++;
	}
	traverse(q3);
	return q3;
}
