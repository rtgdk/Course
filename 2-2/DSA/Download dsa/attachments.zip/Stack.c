# include "Stack.h"

# include <stdio.h>
# include <stdlib.h>

void print_stack(struct Stack *stack) {
	struct Node *iterator = stack->head;
	while(iterator != NULL) {
		printf(" %d ", iterator->data);
		iterator = iterator->next;
	}
	printf("\n");
}

void push(struct Stack *stack, int data) {
	struct Node *new_node = (struct Node *)malloc(sizeof(struct Node));
	new_node->data = data;
	new_node->next = NULL;
	if(stack->head == NULL) {
		stack->head = new_node;
		return;	
	}
	else {
		new_node->next = stack->head;
		stack->head = new_node;
	}
}

int pop(struct Stack *stack) {
	if(stack->head == NULL)	return -1;
	else {
		struct Node *temp = stack->head;
		stack->head = stack->head->next;
		int temp_data = temp->data;
		free(temp);
		return temp_data;
	}
}

